<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AgentDetail extends Model
{
    protected $table = "agent_details";

}