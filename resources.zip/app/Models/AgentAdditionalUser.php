<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AgentAdditionalUser extends Model
{
    protected $table = "agent_additional_users";

   
	
   
}