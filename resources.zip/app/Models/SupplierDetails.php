<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SupplierDetails extends Model
{
    protected $table = "supplier_details";

}