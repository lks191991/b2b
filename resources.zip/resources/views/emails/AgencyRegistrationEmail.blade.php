@extends('emails.layout')
@section('message')

<div style="width: 100%;margin: 20px 0px;padding: 0px 20px">
		<p>
			<strong>Dear Travel Partner,</strong>
		</p>
		<p>Greetings from Abaterab2b!</p>
 
<p>Thank you for your interest and signing up we have received your registration request successfully.</p>
 <p>Your Log in credentials will be sent to your email within 24 hours.</p>
<p>We look forward for working with you.</p>
<p>For any further information or assistance please feel free to contact us.</p>
<p>Note: Please do not reply to this email. It has been sent from an email account that is not monitored.</p>
<p><strong>Thanks </strong></p><p><strong></br>Team Abatera B2B </strong></p>
	</div>
@endsection
