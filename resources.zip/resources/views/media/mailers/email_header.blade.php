<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>Quition Email</title>
<style type="text/css">
body {
    width: 100%;
    background-color: #fff;
    margin: 0;
    padding: 0;
    font-family: Arial, "sans-serif";
    -webkit-font-smoothing: antialiased;
    font-size: 14px;
}
table {
    border-collapse: collapse;
}

@media only screen and (max-width: 700px) {
.mobile {
    width: 100% !important;
}
.text-ct {
    text-align: center !important;
}
}
</style>
</head>

<body>
