<table style="background-color: rgb(255 , 255 , 255)"  class="mobile" width="700" cellspacing="0" cellpadding="0" border="0" align="center">
    <tbody>
      <tr>
        <td width="100%" valign="top"><table class="mobile" width="100%" cellspacing="0" cellpadding="0" border="0" align="center">
            <tbody>
              <tr>
                <td><table  width="100%" cellspacing="0" cellpadding="0" border="0" align="center">
                    <tbody>
                      <tr>
                        <td width="100%" height="35"></td>
                      </tr>
                    </tbody>
                  </table></td>
              </tr>
            </tbody>
          </table></td>
      </tr>
    </tbody>
  </table>

<table style="background-color: rgb(230 , 60 , 106)"  class="mobile" width="700" cellspacing="0" cellpadding="0" border="0" bgcolor="#e63c6a" align="center">
    <tbody>
      <tr>
        <td style="background-image: url(&quot;http://hoodies4schools.co.uk/components/com_h4s/assets/images/quote_email/seperator4.jpg&quot;) ; background-position: center top ; -webkit-background-size: cover ; -moz-background-size: cover ; -o-background-size: cover ; background-size: cover ; background-position: center center ; background-repeat: no-repeat; padding: 0px 10px;" id="sep4"><table class="mobile" width="100%" cellspacing="0" cellpadding="0" border="0" align="center">
            <tbody>
              <tr>
                <td><table  class="mobile" width="600" cellspacing="0" cellpadding="0" border="0" align="center">
                    <tbody>
                      <tr>
                        <td width="100%"><table style="border-collapse: collapse" class="mobile" width="600" cellspacing="0" cellpadding="0" border="0">
                            <tbody>
                              <tr>
                                <td width="100%" height="55"></td>
                              </tr>
                              <tr>
                                <td style="font-size: 26px ; color: rgb(255 , 255 , 255) ; text-align: center ; font-family: &quot;helvetica&quot; , &quot;arial&quot; , sans-serif ; line-height: 32px ; font-weight: bold ; vertical-align: top ; text-transform: uppercase" width="100%" align="center"> let’s talk, call us on 0800 817 4901 </td>
                              </tr>
                              <tr>
                                <td width="100%" height="55"></td>
                              </tr>
                            </tbody>
                          </table></td>
                      </tr>
                    </tbody>
                  </table></td>
              </tr>
            </tbody>
          </table></td>
      </tr>
    </tbody>
  </table>
  <table style="background-color: rgb(255 , 255 , 255)" class="mobile" width="700" cellspacing="0" cellpadding="0" border="0" align="center">
    <tbody>
      <tr>
        <td width="100%" valign="top" style="padding: 0px 10px;"><table class="mobile" width="100%" cellspacing="0" cellpadding="0" border="0" align="center">
            <tbody>
              <tr>
                <td><table  class="mobile" width="600" cellspacing="0" cellpadding="0" border="0" align="center">
                    <tbody>
                      <tr>
                        <td width="100%"><table style="border-collapse: collapse"  class="mobile" width="100%" cellspacing="0" cellpadding="0" border="0" align="center">
                            <tbody>
                              <tr>
                                <td width="100%" height="55"></td>
                              </tr>
                            </tbody>
                          </table>
                          <table style="border-collapse: collapse"  class="mobile" width="340" cellspacing="0" cellpadding="0" border="0" align="left">
                            <tbody>
                              <tr>
                                <td class="icons11" width="100%" valign="top"><table style="border-collapse: collapse"  class="mobile" width="110" cellspacing="0" cellpadding="0" border="0" align="left">
                                    <tbody>
                                      <tr>
                                        <td style="text-align: left ; font-family: &quot;helvetica&quot; , &quot;arial&quot; , sans-serif ; font-size: 14px ; color: rgb(1 , 1 , 1) ; line-height: 24px ; font-weight: bold ; letter-spacing: 1px ; text-transform: uppercase"  width="100%" valign="top" height="30"><span><img src="http://hoodies4schools.co.uk/components/com_h4s/assets/images/quote_email/footer_icon1.png" alt="Address Icon" class="hover" style="vertical-align: middle ; padding-bottom: 4px" width="11" height="auto" border="0"></span> <span> ADDRESS: </span></td>
                                      </tr>
                                    </tbody>
                                  </table>
                                  <table style="border-collapse: collapse"  class="mobile" width="5" cellspacing="0" cellpadding="0" border="0" align="left">
                                    <tbody>
                                      <tr>
                                        <td style="font-size: 1px ; line-height: 1px" width="100%" height="1">&nbsp;</td>
                                      </tr>
                                    </tbody>
                                  </table>
                                  <table style="border-collapse: collapse"  class="mobile" width="210" cellspacing="0" cellpadding="0" border="0" align="left">
                                    <tbody>
                                      <tr>
                                        <td style="text-align: left ; font-family: &quot;helvetica&quot; , &quot;arial&quot; , sans-serif ; font-size: 14px ; color: rgb(119 , 119 , 119) ; line-height: 24px ; font-weight: normal"  width="100%" height="30"> Alliance Business Park, Claret St, Accrington, Lancashire BB5 0RR </td>
                                      </tr>
                                    </tbody>
                                  </table></td>
                              </tr>
                              <tr>
                                <td width="100%" height="20"></td>
                              </tr>
                              <tr>
                                <td class="icons11" width="100%" valign="top"><table style="border-collapse: collapse" class="mobile" width="110" cellspacing="0" cellpadding="0" border="0" align="left">
                                    <tbody>
                                      <tr>
                                        <td style="text-align: left ; font-family: &quot;helvetica&quot; , &quot;arial&quot; , sans-serif ; font-size: 14px ; color: rgb(1 , 1 , 1) ; line-height: 24px ; font-weight: bold ; letter-spacing: 1px ; text-transform: uppercase" width="100%" valign="top" height="30"><span><img src="http://hoodies4schools.co.uk/components/com_h4s/assets/images/quote_email/footer_icon2.png" alt="Phone Number Icon" class="hover" style="vertical-align: middle ; padding-bottom: 4px" width="11" height="auto" border="0"></span> <span> phone: </span></td>
                                      </tr>
                                    </tbody>
                                  </table>
                                  <table style="border-collapse: collapse" width="5" cellspacing="0" cellpadding="0" border="0" align="left">
                                    <tbody>
                                      <tr>
                                        <td style="font-size: 1px ; line-height: 1px" width="100%" height="1">&nbsp;</td>
                                      </tr>
                                    </tbody>
                                  </table>
                                  <table style="border-collapse: collapse" class="mobile" width="210" cellspacing="0" cellpadding="0" border="0" align="left">
                                    <tbody>
                                      <tr>
                                        <td style="text-align: left ; font-family: &quot;helvetica&quot; , &quot;arial&quot; , sans-serif ; font-size: 14px ; color: rgb(119 , 119 , 119) ; line-height: 24px ; font-weight: normal"  width="100%" height="30"> 0800 817 4901 </td>
                                      </tr>
                                    </tbody>
                                  </table></td>
                              </tr>
                              <tr>
                                <td width="100%" height="20"></td>
                              </tr>
                              <tr>
                                <td class="icons11" width="100%" valign="top"><table style="border-collapse: collapse" class="mobile" width="110" cellspacing="0" cellpadding="0" border="0" align="left">
                                    <tbody>
                                      <tr>
                                        <td style="text-align: left ; font-family: &quot;helvetica&quot; , &quot;arial&quot; , sans-serif ; font-size: 14px ; color: rgb(1 , 1 , 1) ; line-height: 24px ; font-weight: bold ; letter-spacing: 1px ; text-transform: uppercase"  width="100%" valign="top" height="30"><span><img src="http://hoodies4schools.co.uk/components/com_h4s/assets/images/quote_email/footer_icon3.png" alt="Email Address Icon" class="hover" style="vertical-align: middle ; padding-bottom: 4px" width="11" height="auto" border="0"></span> <span> email: </span></td>
                                      </tr>
                                    </tbody>
                                  </table>
                                  <table style="border-collapse: collapse"  width="5" cellspacing="0" cellpadding="0" border="0" align="left">
                                    <tbody>
                                      <tr>
                                        <td style="font-size: 1px ; line-height: 1px" width="100%" height="1">&nbsp;</td>
                                      </tr>
                                    </tbody>
                                  </table>
                                  <table style="border-collapse: collapse" class="mobile" width="210" cellspacing="0" cellpadding="0" border="0" align="left">
                                    <tbody>
                                      <tr>
                                        <td style="text-align: left ; font-family: &quot;helvetica&quot; , &quot;arial&quot; , sans-serif ; font-size: 14px ; color: rgb(119 , 119 , 119) ; line-height: 24px ; font-weight: normal" width="100%" height="30"><a href="https://www.mailinator.com/key/url?url=mailto%3Ainfo@hoodies4schools.co.uk" style="text-decoration: none ; color: rgb(119 , 119 , 119)" target="_other" rel="nofollow">info@hoodies4schools.co.uk</a></td>
                                      </tr>
                                    </tbody>
                                  </table></td>
                              </tr>
                              <tr>
                                <td width="100%" height="30"></td>
                              </tr>
                            </tbody>
                          </table>
                          <table style="border-collapse: collapse" class="mobile" width="250" cellspacing="0" cellpadding="0" border="0" align="right">
                            <tbody>
                              <tr>
                                <td  width="100%" valign="top"><table style="border-collapse: collapse" class="mobile" width="110" cellspacing="0" cellpadding="0" border="0" align="left">
                                    <tbody>
                                      <tr>
                                        <td style="text-align: left ; font-family: &quot;helvetica&quot; , &quot;arial&quot; , sans-serif ; font-size: 14px ; color: rgb(1 , 1 , 1) ; line-height: 24px ; font-weight: bold ; letter-spacing: 1px ; text-transform: uppercase"  width="100%" valign="top" height="30"><span><img src="http://hoodies4schools.co.uk/components/com_h4s/assets/images/quote_email/footer_icon4.png" alt="Opening Hours Icon" class="hover" style="vertical-align: middle ; padding-bottom: 4px" width="12" height="auto" border="0"></span> <span> Hours: </span></td>
                                      </tr>
                                    </tbody>
                                  </table>
                                  <table style="border-collapse: collapse" width="5" cellspacing="0" cellpadding="0" border="0" align="left">
                                    <tbody>
                                      <tr>
                                        <td style="font-size: 1px ; line-height: 1px" width="100%" height="1">&nbsp;</td>
                                      </tr>
                                    </tbody>
                                  </table>
                                  <table style="border-collapse: collapse" class="mobile" width="150" cellspacing="0" cellpadding="0" border="0" align="left">
                                    <tbody>
                                      <tr>
                                        <td style="text-align: left ; font-family: &quot;helvetica&quot; , &quot;arial&quot; , sans-serif ; font-size: 14px ; color: rgb(119 , 119 , 119) ; line-height: 24px ; font-weight: normal" width="100%" height="30"> Mon - Fri: 09:00 - 17:30 <br>
                                          Saturday: 10:00 - 16:00 <br>
                                          Sunday: Closed </td>
                                      </tr>
                                      <tr>
                                        <td style="font-size: 1px ; line-height: 1px" width="100%" height="25">&nbsp;</td>
                                      </tr>
                                      <tr>
                                        <td style="text-align: left ; font-family: &quot;helvetica&quot; , &quot;arial&quot; , sans-serif ; font-size: 14px ; color: rgb(1 , 1 , 1) ; line-height: 24px ; font-weight: bold ; text-transform: uppercase" width="100%" valign="top"><a href="https://www.mailinator.com/key/url?url=https%3A//twitter.com/Hoodies4Schools" title="Hoodies 4 Schools on Twitter" target="_other" rel="nofollow"><img src="http://hoodies4schools.co.uk/components/com_h4s/assets/images/quote_email/social_icon1.png" alt="Hoodies 4 Schools on Twitter" class="hover" style="vertical-align: middle ; padding-right: 1px" width="32" height="auto" border="0"></a> <a href="https://www.mailinator.com/key/url?url=https%3A//www.facebook.com/Hoodies4Schools" title="Hoodies 4 Schools on Facebook" target="_other" rel="nofollow"><img src="http://hoodies4schools.co.uk/components/com_h4s/assets/images/quote_email/social_icon2.png" alt="Hoodies 4 Schools on Facebook" class="hover" style="vertical-align: middle ; padding-right: 1px" width="32" height="auto" border="0"></a></td>
                                      </tr>
                                    </tbody>
                                  </table></td>
                              </tr>
                              <tr>
                                <td width="100%" height="20"></td>
                              </tr>
                              <tr>
                                <td width="100%" height="20"></td>
                              </tr>
                            </tbody>
                          </table></td>
                      </tr>
                    </tbody>
                  </table>
                  <table style="border-collapse: collapse" width="100%" cellspacing="0" cellpadding="0" border="0" align="left">
                    <tbody>
                      <tr>
                        <td width="100%" height="35"></td>
                      </tr>
                    </tbody>
                  </table></td>
              </tr>
            </tbody>
          </table></td>
      </tr>
    </tbody>
  </table>
  <table style="background-color: rgb(29 , 34 , 43) ; background-image: none" class="mobile" width="700" cellspacing="0" cellpadding="0" border="0" bgcolor="#282828" align="center">
    <tbody>
      <tr>
        <td style="background-image: none ; background-size: cover ; background-position: center center ; background-repeat: no-repeat ; background-color: rgb(29 , 34 , 43)" id="sep5"><table class="mobile" width="100%" cellspacing="0" cellpadding="0" border="0" align="center">
            <tbody>
              <tr>
                <td><table class="mobile" width="600" cellspacing="0" cellpadding="0" border="0" align="center">
                    <tbody>
                      <tr>
                        <td width="100%"><table style="border-collapse: collapse"  width="100%" cellspacing="0" cellpadding="0" border="0" align="center">
                            <tbody>
                              <tr>
                                <td width="100%" height="25"></td>
                              </tr>
                            </tbody>
                          </table>
                          <table style="border-collapse: collapse" width="100%" cellspacing="0" cellpadding="0" border="0" align="center">
                            <tbody>
                              <tr>
                                <td class="mobile" width="100%" align="center"><table class="mobile" width="200" cellspacing="0" cellpadding="0" border="0" align="center">
                                    <tbody>
                                      <tr>
                                        <td  width="100%"><table cellspacing="0" cellpadding="0" border="0" align="center">
                                            <tbody>
                                              <tr>
                                                <td class="logo" width="200" align="center"><a href="javascript:void(0)" style="text-decoration: none" target="_other" rel="nofollow"><img src="http://hoodies4schools.co.uk/components/com_h4s/assets/images/quote_email/logo-footer.png" style="width: 80px ; height: auto" alt="Hoodies 4 Schools Logo Icon" class="hover" width="80" height="auto" border="0"></a></td>
                                              </tr>
                                            </tbody>
                                          </table></td>
                                      </tr>
                                    </tbody>
                                  </table></td>
                              </tr>
                            </tbody>
                          </table>
                          <table style="border-collapse: collapse"  width="100%" cellspacing="0" cellpadding="0" border="0" align="center">
                            <tbody>
                              <tr>
                                <td width="100%" height="30"></td>
                              </tr>
                            </tbody>
                          </table>
                          <table style="border-collapse: collapse" width="100%" cellspacing="0" cellpadding="0" border="0" align="center">
                            <tbody>
                              <tr>
                                <td style="font-size: 13px ; color: rgb(255 , 255 , 255) ; font-family: &quot;helvetica&quot; , &quot;arial&quot; , sans-serif ; line-height: 22px ; vertical-align: top ; font-weight: normal" width="100%" align="center"> Copyright © 2014 Hoodies 4 Schools By </td>
                              </tr>
                            </tbody>
                          </table>
                          <table style="border-collapse: collapse" width="100%" cellspacing="0" cellpadding="0" border="0" align="center">
                            <tbody>
                              <tr>
                                <td width="100%" height="10"></td>
                              </tr>
                              <tr>
                                <td style="font-size: 13px ; color: rgb(188 , 188 , 188) ; font-family: &quot;helvetica&quot; , &quot;arial&quot; , sans-serif ; line-height: 22px ; vertical-align: top ; border-color: rgb(230 , 60 , 106)" width="100%" align="center"><a href="" style="text-decoration: none ; color: rgb(230 , 60 , 106) ; border-color: rgb(230 , 60 , 106)" target="_other" rel="nofollow">Unsubscribe</a></td>
                              </tr>
                            </tbody>
                          </table>
                          <table style="border-collapse: collapse" width="100%" cellspacing="0" cellpadding="0" border="0" align="center">
                            <tbody>
                              <tr>
                                <td width="100%" height="25"></td>
                              </tr>
                              <tr>
                                <td style="font-size: 1px ; line-height: 1px" height="1">&nbsp;</td>
                              </tr>
                            </tbody>
                          </table></td>
                      </tr>
                    </tbody>
                  </table></td>
              </tr>
            </tbody>
          </table></td>
      </tr>
    </tbody>
  </table>
  <table class="mobile" width="100%" cellspacing="0" cellpadding="0" border="0" align="center">
    <tbody>
      <tr>
        <td><table class="full" width="100%" cellspacing="0" cellpadding="0" border="0" align="center">
            <tbody>
              <tr>
                <td width="100%" height="35"></td>
              </tr>
            </tbody>
          </table></td>
      </tr>
    </tbody>
  </table>
  </body>
  </html>
