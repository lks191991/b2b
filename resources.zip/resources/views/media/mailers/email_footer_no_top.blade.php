<img src="http://ordering.hoodies4schools.co.uk/images/LetsTalk.jpg">
<div class="Email__Footer_text">
    <table border="0" class="Email__Footer_table">
        <tr>
            <td class="Email__Footer_dark"><i class="fa fa-map-marker" aria-hidden="true"></i> <b>ADDRESS:</b></td>
            <td class="Email__Footer_text">Alliance Business Park, Claret St,<br> Accrington, Lancashire BB5 0RR</td>
            <td class="Email__Footer_dark" rowspan="2"><i class="fa fa-clock-o"></i> <b>HOURS:</b></td>
            <td class="Email__Footer_text" rowspan="2"><b>Mon-Fri: </b>09:00 - 17:30<br>
                <b>Saturday: </b>10:00 - 16:00<br>
                <b>Sunday: </b>Closed
            </td>
        </tr>
        <tr>
            <td class="Email__Footer_dark"><i class="fa fa-phone" aria-hidden="true"></i> <b>PHONE:</b></td>
            <td class="Email__Footer_text">0800 817 4901</td>

        </tr>
        <tr>
            <td class="Email__Footer_dark"><i class="fa fa fa-pencil" aria-hidden="true"></i> <b>EMAIL:</b></td>
            <td class="Email__Footer_text">info@hoodies4schools.co.uk</td>
            <td>&nbsp;</td>
            <td>
                <a href="https://twitter.com/Hoodies4Schools" class="Email__Footer_social">
                    <span class="fa-stack fa-lg">
                        <i class="fa fa-circle fa-stack-2x"></i>
                        <i class="fa fa-twitter fa-stack-1x fa-inverse"></i>
                    </span>
                </a>
                <a href="https://www.facebook.com/Hoodies4Schools" class="Email__Footer_social">
                    <span class="fa-stack fa-lg">
                        <i class="fa fa-circle fa-stack-2x"></i>
                        <i class="fa fa fa-facebook fa-stack-1x fa-inverse"></i>
                    </span>
                </a>
            </td>
        </tr>
    </table>
    <div class="col-sm-12 Email__Footer_bottom" align="center">
        <p align="center">
            <a href="http://hoodies4schools.co.uk" target="_blank">
                <img src="http://ordering.hoodies4schools.co.uk/images/small-logo.png" />
            </a>&nbsp;
            <a href="http://schoolaprons.co.uk" target="_blank">
                <img src="http://ordering.hoodies4schools.co.uk/images/a4s-alt.png" />
            </a>
        </p>
        <p>Copyright &copy; 2014 Hoodies 4 Schools By</p>
        <p>&nbsp;</p>
        <p><a href="http://ordering.hoodies4schools.co.uk/unsubscribe/{{$contact->id}}" style="color: #ff3366;">Unsubscribe</a></p>
    </div>
</div>

</body>
</html>
